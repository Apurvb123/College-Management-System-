/* script.js - College Management System
   Sections: data and seed -> algorithms (merge sort, binary search) -> helpers -> charts
             -> actions (add, delete, save) -> forms and lists -> panels (Principal, HOD, Teacher, Student) -> render.
   Data is stored in the browser with localStorage, so no server or database is needed. */
const K='cms_v3';
const DAYS=['Mon','Tue','Wed','Thu','Fri','Sat'];
const SLOTS=['9:00-10:00','10:00-11:00','11:15-12:15','12:15-1:15','2:00-3:00'];
const SEMS=[3,5,7],YEAR={3:'2nd year',5:'3rd year',7:'Final year'};
const semL=n=>`Sem ${n} (${YEAR[n]})`;
const uid=()=>Math.random().toString(36).slice(2,9);
const iso=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
const ago=n=>{const d=new Date();d.setDate(d.getDate()-n);return d};
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const $=id=>document.getElementById(id);
const v=id=>($(id)?$(id).value.trim():'');
let tm;
function note(m,bad=1){const t=$('toast');t.textContent=m;t.className='toast '+(bad?'bad':'ok');t.hidden=false;clearTimeout(tm);tm=setTimeout(()=>{t.hidden=true},3500)}

function seed(){
  const R=(()=>{let x=11;return()=>(x=(x*16807)%2147483647)/2147483647})();
  const depts=[{id:'it',name:'IT'},{id:'cse',name:'CSE'},{id:'ce',name:'CE'},{id:'me',name:'ME'}];
  const cur={
    cse:{3:['DSA','OOP','DM','CO'],5:['AAD','DS','PM','CS','SS/ADBMS','WAD'],7:['AI','ML','CC','IS']},
    it:{3:['DSA','OOP','DBMS'],5:['AAD','SE','WT'],7:['IoT','Big Data','Cyber Security']},
    ce:{3:['Surveying','Fluid Mechanics','Building Materials'],5:['Structural Analysis','Geotechnical Engg','Hydrology'],7:['Steel Structures','Transportation Engg','Estimation and Costing']},
    me:{3:['Thermodynamics','Mechanics of Solids','Manufacturing Processes'],5:['Heat Transfer','Machine Design','Fluid Machinery'],7:['CAD/CAM','Refrigeration and AC','Industrial Engg']}
  };
  const users=[{id:'p1',name:'Dr. Mehta (Principal)',user:'principal',pass:'admin123',role:'principal'}];
  const hods={cse:['Prof. Shah','hod'],it:['Prof. Nair','hod.it'],ce:['Prof. Rao','hod.ce'],me:['Prof. Iyer','hod.me']};
  depts.forEach(d=>users.push({id:'h_'+d.id,name:hods[d.id][0]+' (HOD)',user:hods[d.id][1],pass:'hod123',role:'hod',dept:d.id}));
  const TN=['Desai','Trivedi','Joshi','Bhatt','Parmar','Vyas','Pandya','Dave','Mistry','Chauhan','Solanki','Thakkar','Oza','Raval','Modi','Gandhi','Amin','Kapadia'],IN=['A.','K.','M.','N.','R.','S.','V.'];
  const special=['aad','ds','pm','cs','ss','wad'];let ti=0;
  depts.forEach(d=>SEMS.forEach(s=>cur[d.id][s].forEach((sj,i)=>{
    const user=(d.id=='cse'&&s==5)?special[i]:`${d.id}${s}.${sj.toLowerCase().replace(/[^a-z0-9]/g,'')}`;
    users.push({id:'t'+ti,name:`Prof. ${IN[ti%7]} ${TN[ti%18]}`,user,pass:'t123',role:'teacher',dept:d.id,sem:s,subject:sj});ti++;
  })));
  const named=[['PATEL DEV','dev',.92],['TUSHAR SEVAK','tushar',.8],['BAROT APURV','apurv',.68],['PRIYANSH PRAJAPATI','priyansh',.86],['KEYUR ZALA','keyur',.73]];
  const FN=['AARAV','DIYA','KRISH','MEERA','ROHAN','ANAYA','YASH','ISHA','HARSH','KAVYA','NIRAV','POOJA','JAY','RIYA','SMIT','TANVI','OM','NIDHI','PARTH','SNEHA','HET','KHUSHI','DHRUV','MANSI'],LN=['SHAH','PATEL','MEHTA','DESAI','JOSHI','PARIKH','VORA','PANCHAL'];
  let k=0,si=0;const rate={};
  depts.forEach(d=>SEMS.forEach(s=>{
    const n=d.id=='cse'?(s==5?5:4):3;
    for(let i=0;i<n;i++){
      const c=(d.id=='cse'&&s==5)?named[i]:[FN[k%FN.length]+' '+LN[(k*3+1)%LN.length],`${d.id}${s}s${i+1}`,.6+R()*.35];
      if(!(d.id=='cse'&&s==5))k++;
      const id='s'+si++;rate[id]=c[2];
      users.push({id,name:c[0],user:c[1],pass:'s123',role:'student',dept:d.id,sem:s,roll:(d.id=='cse'?'':d.id.toUpperCase()+'-')+(s*100+i+1)});
    }
  }));
  const att=[],tt={};
  depts.forEach(d=>SEMS.forEach(s=>{
    const gt=users.filter(u=>u.role=='teacher'&&u.dept==d.id&&u.sem==s),gs=users.filter(u=>u.role=='student'&&u.dept==d.id&&u.sem==s);
    for(let n=34;n>=0;n--){const dt=ago(n);if(dt.getDay()==0)continue;
      for(let q=0;q<3;q++){const t=gt[(dt.getDate()+q)%gt.length],rec={};gs.forEach(x=>rec[x.id]=R()<rate[x.id]);att.push({id:uid(),teacher:t.id,subject:t.subject,date:iso(dt),rec})}}
    const l=cur[d.id][s],g={};DAYS.forEach((_,di)=>SLOTS.forEach((_,sl)=>g[di+'-'+sl]=l[(di*2+sl)%l.length]));tt[d.id+'|'+s]=g;
  }));
  const results=[];
  users.filter(u=>u.role=='student').forEach(u=>{for(let j=1;j<u.sem;j++){const g=Math.max(5,Math.min(9.8,5.5+rate[u.id]*3.2+(R()-.5)*1.2));results.push({id:uid(),student:u.id,sem:j,sgpa:Math.round(g*10)/10,status:'Pass'})}});
  const T=(d,s,sj)=>users.find(u=>u.role=='teacher'&&u.dept==d&&u.sem==s&&u.subject==sj).id;
  const materials=[
    {id:'m1',teacher:T('cse',5,'AAD'),dept:'cse',sem:5,subject:'AAD',title:'Unit 1: Divide and conquer notes',link:'Recurrences, merge sort, binary search'},
    {id:'m2',teacher:T('cse',5,'DS'),dept:'cse',sem:5,subject:'DS',title:'Trees and graphs slides',link:'https://example.com/ds-trees'},
    {id:'m3',teacher:T('cse',5,'WAD'),dept:'cse',sem:5,subject:'WAD',title:'HTML/CSS lab manual',link:'Lab 1 to 6'},
    {id:'m4',teacher:T('cse',3,'DSA'),dept:'cse',sem:3,subject:'DSA',title:'Arrays and linked lists',link:'Unit 1 notes'},
    {id:'m5',teacher:T('cse',7,'ML'),dept:'cse',sem:7,subject:'ML',title:'Regression and classification',link:'Unit 1 slides'}];
  return{depts,cur,users,attendance:att,tt,results,materials};
}
let db;try{db=JSON.parse(localStorage.getItem(K))}catch(e){}
if(!db||!db.depts||!db.cur)db=seed();
const save=()=>{try{localStorage.setItem(K,JSON.stringify(db))}catch(e){}};
let me=null,tab=0,sel=null,tdept=null,tsem=5,fsem=0,pdept='';

/* ---- Algorithms ---- */
const cmpNum=(a,b)=>String(a).localeCompare(String(b),undefined,{numeric:true});
function mergeSort(a,cmp){ // divide and conquer, O(n log n)
  if(a.length<2)return a;
  const m=a.length>>1,l=mergeSort(a.slice(0,m),cmp),r=mergeSort(a.slice(m),cmp),o=[];
  let i=0,j=0;
  while(i<l.length&&j<r.length)o.push(cmp(l[i],r[j])<=0?l[i++]:r[j++]);
  return o.concat(l.slice(i),r.slice(j));
}
function binSearch(a,key,f){ // O(log n)
  let lo=0,hi=a.length-1;
  while(lo<=hi){const m=(lo+hi)>>1,c=cmpNum(f(a[m]),key);if(!c)return m;c<0?lo=m+1:hi=m-1}
  return -1;
}

/* ---- Helpers ---- */
const U=id=>db.users.find(u=>u.id==id)||{};
const dn=id=>(db.depts.find(d=>d.id==id)||{}).name||'-';
const byRole=(r,f)=>db.users.filter(u=>u.role==r&&(!f||f(u)));
const subs=(d,s)=>((db.cur[d]||{})[s])||[];
const tOf=(d,s,sj)=>(byRole('teacher',t=>t.dept==d&&t.sem==s&&t.subject==sj)[0]||{}).name||'';
const bySem=(a,b)=>a.sem-b.sem||cmpNum(a.roll,b.roll);
const pcCls=x=>x==null?'':x>=75?'ok':'bad';
const table=(h,rows,empty)=>rows.length?`<div class="tw"><table><tr>${h.map(x=>`<th>${x}</th>`).join('')}</tr>${rows.map(r=>`<tr>${r.map(c=>`<td>${c}</td>`).join('')}</tr>`).join('')}</table></div>`:`<p class="mu">${empty||'Nothing here yet.'}</p>`;
const delBtn=(fn,id,label)=>`<button class="g d" onclick="ask(this,'${fn}','${id}')">${label||'Delete'}</button>`;
function ask(b,fn,id){ // two-step delete, since dialogs are not available
  if(b.dataset.a){globalThis[fn](id);return}
  b.dataset.a=1;b.dataset.t=b.textContent;b.textContent='Confirm?';
  setTimeout(()=>{if(b.isConnected){delete b.dataset.a;b.textContent=b.dataset.t}},3000);
}
const stat=(n,l)=>`<div class="stat"><b>${n}</b><small>${l}</small></div>`;
const opts=(a,sel)=>a.map(x=>`<option value="${esc(x[0])}" ${x[0]==sel?'selected':''}>${esc(x[1])}</option>`).join('');
const lk=l=>/^https?:\/\//.test(l)?`<a href="${esc(l)}" target="_blank" rel="noopener">Open link</a>`:esc(l);
const bars=(it,max,warn)=>it.map(i=>`<div class="br"><span>${esc(i.l)}</span><div class="bt"><i class="${warn&&i.v<warn?'lo':''}" style="width:${Math.min(100,i.v/max*100)}%"></i></div><b>${i.t}</b></div>`).join('');
const monthData=sid=>{const f=iso(ago(29));return db.attendance.filter(a=>a.date>=f&&sid in a.rec).sort((a,b)=>a.date.localeCompare(b.date))};
const monthPct=(sid,sj)=>{const s=monthData(sid).filter(a=>!sj||a.subject==sj);return s.length?Math.round(s.filter(a=>a.rec[sid]).length*100/s.length):null};
function classPct(f){ // attendance % over 30 days for sessions whose teacher matches f
  const from=iso(ago(29));let p=0,n=0;
  db.attendance.forEach(a=>{if(a.date<from||!f(U(a.teacher)))return;for(const k in a.rec){n++;if(a.rec[k])p++}});
  return n?Math.round(p*100/n):null;
}
const noDept='<div class="card"><p class="mu">Add a department first.</p></div>';

/* ---- Charts ---- */
function lineChart(pts){
  const W=640,H=250,L=40,R=14,T=14,B=30,w=W-L-R,h=H-T-B,X=f=>L+f*w,Y=y=>T+h-y/100*h;
  let g='';[0,25,50,75,100].forEach(y=>g+=`<line x1="${L}" x2="${W-R}" y1="${Y(y)}" y2="${Y(y)}" class="gl${y==75?' th':''}"/><text x="${L-6}" y="${Y(y)+4}" text-anchor="end" class="tx">${y}%</text>`);
  const P=pts.map(p=>[X(p.f),Y(p.y)]),ln=P.map((p,i)=>(i?'L':'M')+p[0].toFixed(1)+' '+p[1].toFixed(1)).join('');
  const ar=ln+`L${P[P.length-1][0]} ${Y(0)}L${P[0][0]} ${Y(0)}Z`;
  const lab=[pts[0],pts[pts.length>>1],pts[pts.length-1]];
  return`<svg viewBox="0 0 ${W} ${H}" width="100%" role="img" aria-label="Attendance percentage over the last 30 days">${g}<path d="${ar}" class="ar"/><path d="${ln}" class="ln"/>${P.map(p=>`<circle cx="${p[0].toFixed(1)}" cy="${p[1].toFixed(1)}" r="3" class="dt"/>`).join('')}${lab.map(p=>`<text x="${X(p.f)}" y="${H-8}" text-anchor="middle" class="tx">${p.d.slice(8)}/${p.d.slice(5,7)}</text>`).join('')}</svg>`;
}
function attReport(sid,sj){
  const s=U(sid),ss=monthData(sid).filter(a=>!sj||a.subject==sj);
  if(!ss.length)return'<div class="card"><h3>Attendance, last 30 days</h3><p class="mu">No attendance recorded yet.</p></div>';
  let p=0,t=0;const by={},sub={};
  ss.forEach(a=>{const o=sub[a.subject]=sub[a.subject]||{p:0,t:0};t++;o.t++;if(a.rec[sid]){p++;o.p++}by[a.date]=Math.round(p*100/t)});
  const f0=Date.parse(iso(ago(29))),pts=Object.keys(by).map(d=>({d,y:by[d],f:(Date.parse(d)-f0)/864e5/29}));
  const order=subs(s.dept,s.sem);
  const items=Object.keys(sub).sort((a,b)=>order.indexOf(a)-order.indexOf(b)).map(x=>{const q=Math.round(sub[x].p*100/sub[x].t);return{l:x,v:q,t:q+'% ('+sub[x].p+'/'+sub[x].t+')'}});
  const all=Math.round(p*100/t),low=items.filter(i=>i.v<75).length;
  return`<div class="stats">${stat(all+'%','Attendance, last 30 days')}${stat(p+' / '+t,'Lectures attended')}${stat(low,'Subjects below 75%')}</div>
<div class="card"><h3>Attendance trend (running percentage)</h3><p class="mu">The dashed line marks the 75% minimum.</p>${lineChart(pts)}</div>
<div class="card"><h3>Subject-wise attendance</h3>${bars(items,100,75)}</div>`;
}
function resultsCard(sid,staff){
  const s=U(sid),r=mergeSort(db.results.filter(x=>x.student==sid),(a,b)=>a.sem-b.sem);
  return`<div class="card"><h3>Past semester results</h3>${r.length?bars(r.map(x=>({l:'Semester '+x.sem,v:x.sgpa,t:x.sgpa.toFixed(1)})),10,0):''}${table(['Semester','SGPA','Result'],r.map(x=>[x.sem,x.sgpa.toFixed(1),`<span class="${x.status=='Pass'?'ok':'bad'}">${esc(x.status)}</span>`]),'No results added yet.')}
${staff?`<div class="row" style="margin-top:.75rem"><label>Semester<select id="rsem">${Array.from({length:Math.max(1,(s.sem||5)-1)},(_,i)=>`<option>${i+1}</option>`).join('')}</select></label><label>SGPA<input id="rsg" type="number" step="0.1" min="0" max="10"></label><label>Result<select id="rst"><option>Pass</option><option>ATKT</option><option>Fail</option></select></label><button class="b" onclick="addResult('${sid}')">Save result</button></div>`:''}</div>`;
}
function ttView(dept,sem,edit){
  const g=db.tt[dept+'|'+sem]||{},today=(new Date().getDay()+6)%7,l=subs(dept,sem);
  return(edit&&!l.length?'<div class="card"><p class="mu">Add subjects for this semester in the Subjects tab, then pick them here.</p></div>':'')+
  `<div class="card tw"><table><tr><th>Time</th>${DAYS.map((d,i)=>`<th class="${i==today?'td':''}">${d}</th>`).join('')}</tr>`+SLOTS.map((t,s)=>`<tr><th>${t}</th>`+DAYS.map((_,d)=>{const k=d+'-'+s,val=g[k]||'';
    return edit?`<td><select aria-label="${DAYS[d]} ${t}" onchange="setTT('${dept}',${sem},'${k}',this.value)"><option value="">-</option>${l.map(x=>`<option ${x==val?'selected':''}>${esc(x)}</option>`).join('')}</select></td>`
    :`<td class="${d==today?'td':''}">${val?`<b>${esc(val)}</b><br><span class="mu">${esc(tOf(dept,sem,val))}</span>`:''}</td>`}).join('')+'</tr>').join('')+'</table></div>';
}
function stuReport(dept,sem,sj){
  const ss=mergeSort(byRole('student',s=>s.dept==dept&&(!sem||s.sem==sem)),bySem);
  if(!ss.length)return'<div class="card"><p class="mu">Add a student first.</p></div>';
  if(!ss.some(s=>s.id==sel))sel=ss[0].id;
  const s=U(sel);
  return`<div class="card"><label style="max-width:360px">Student<select onchange="sel=this.value;render()">${opts(ss.map(x=>[x.id,x.roll+' · '+x.name+' (Sem '+x.sem+')']),sel)}</select></label></div>`+
  `<h2>${esc(s.name)} <span class="mu">Roll ${esc(s.roll)}, ${semL(s.sem)}, ${esc(dn(s.dept))}</span></h2>`+attReport(sel,sj)+resultsCard(sel,true);
}

/* ---- Actions ---- */
function login(){
  const u=db.users.find(x=>x.user==v('lu')&&x.pass==$('lp').value);
  if(!u){$('err').textContent='Wrong username or password.';return}
  me=u;tab=0;sel=null;fsem=0;tsem=5;tdept=null;pdept='';render();
}
const logout=()=>{me=null;render()};
function addUser(role,extra={}){
  const name=v('n'),user=v('u'),pass=v('p');
  if(!name||!user||!pass)return note('Fill in name, username and password.');
  if(db.users.some(x=>x.user==user))return note('That username is taken. Pick another.');
  const o={id:uid(),name,user,pass,role,...extra};
  if(!o.dept)o.dept=v('dp');
  if(!db.depts.some(d=>d.id==o.dept))return note('Choose a department.');
  if(role=='hod'&&db.users.some(u=>u.role=='hod'&&u.dept==o.dept))return note('This department already has a HOD. Delete the current HOD first.');
  if(role=='student'){
    o.roll=v('r');o.sem=o.sem||+v('sm')||5;
    if(!o.roll)return note('Enter a roll number.');
    if(db.users.some(u=>u.role=='student'&&u.roll==o.roll))return note('That roll number is already used.');
  }
  if(role=='teacher'){
    o.sem=o.sem||+v('sm');o.subject=v('sb');
    if(!o.subject)return note('This semester has no subjects yet. Add one in the Subjects tab first.');
    if(db.users.some(u=>u.role=='teacher'&&u.dept==o.dept&&u.sem==o.sem&&u.subject==o.subject))return note('That subject already has a teacher.');
  }
  db.users.push(o);save();note(name+' added.',0);render();
}
function delUser(id){
  db.users=db.users.filter(u=>u.id!=id);
  db.materials=db.materials.filter(m=>m.teacher!=id);
  db.attendance=db.attendance.filter(a=>a.teacher!=id);
  db.attendance.forEach(a=>delete a.rec[id]);
  db.results=db.results.filter(r=>r.student!=id);
  save();render();
}
function addDept(){
  const n=v('dname');if(!n)return note('Enter a department name.');
  if(db.depts.some(d=>d.name.toLowerCase()==n.toLowerCase()))return note('That department already exists.');
  const id=uid();db.depts.push({id,name:n});db.cur[id]={3:[],5:[],7:[]};save();note(n+' added.',0);render();
}
function delDept(id){
  if(db.users.some(u=>u.dept==id))return note('Remove this department\'s HOD, teachers and students first.');
  db.depts=db.depts.filter(d=>d.id!=id);delete db.cur[id];
  Object.keys(db.tt).forEach(k=>{if(k.startsWith(id+'|'))delete db.tt[k]});
  save();render();
}
function addSubject(dept,s){
  const n=v('sn'+s);if(!n)return note('Enter a subject name.');
  db.cur[dept]=db.cur[dept]||{};const l=db.cur[dept][s]=db.cur[dept][s]||[];
  if(l.some(x=>x.toLowerCase()==n.toLowerCase()))return note('That subject already exists for this semester.');
  l.push(n);save();note(n+' added to '+semL(s)+'.',0);render();
}
function delSubject(dept,s,i){
  const l=subs(dept,s),n=l[i];if(n==null)return;
  if(byRole('teacher',t=>t.dept==dept&&t.sem==s&&t.subject==n).length)return note('Remove the teacher of '+n+' first.');
  l.splice(i,1);const g=db.tt[dept+'|'+s]||{};for(const k in g)if(g[k]==n)g[k]='';
  save();render();
}
function addTeacherAt(dept,s){
  const name=v('tn'+s),user=v('tu'+s),pass=v('tp'+s),subject=v('ts'+s);
  if(!name||!user||!pass)return note('Fill in name, username and password.');
  if(!subject)return note('Pick a subject.');
  if(db.users.some(x=>x.user==user))return note('That username is taken. Pick another.');
  if(db.users.some(u=>u.role=='teacher'&&u.dept==dept&&u.sem==s&&u.subject==subject))return note('That subject already has a teacher.');
  db.users.push({id:uid(),name,user,pass,role:'teacher',dept,sem:s,subject});save();note(name+' added for '+subject+'.',0);render();
}
function setTT(d,s,k,val){const key=d+'|'+s;db.tt[key]=db.tt[key]||{};db.tt[key][k]=val;save()}
function addMaterial(){
  const t=v('mt');if(!t)return note('Enter a title.');
  db.materials.push({id:uid(),teacher:me.id,dept:me.dept,sem:me.sem,subject:me.subject,title:t,link:v('ml')});save();note('Material added.',0);render();
}
function delMat(id){db.materials=db.materials.filter(m=>m.id!=id);save();render()}
function saveAtt(){
  const date=v('ad');if(!date)return note('Pick a date.');
  const rec={};byRole('student',s=>s.dept==me.dept&&s.sem==me.sem).forEach(s=>rec[s.id]=$('c'+s.id).checked);
  db.attendance=db.attendance.filter(a=>!(a.teacher==me.id&&a.date==date));
  db.attendance.push({id:uid(),teacher:me.id,subject:me.subject,date,rec});save();note('Attendance saved for '+date+'.',0);render();
}
function delAtt(id){db.attendance=db.attendance.filter(a=>a.id!=id);save();render()}
function addResult(sid){
  const g=parseFloat(v('rsg'));if(isNaN(g)||g<0||g>10)return note('SGPA must be between 0 and 10.');
  const sem=+v('rsem');db.results=db.results.filter(r=>!(r.student==sid&&r.sem==sem));
  db.results.push({id:uid(),student:sid,sem,sgpa:g,status:v('rst')});save();note('Result saved.',0);render();
}
function findRoll(){
  const l=mergeSort(byRole('student',s=>(!me.dept||s.dept==me.dept)&&(me.role!='teacher'||s.sem==me.sem)),(a,b)=>cmpNum(a.roll,b.roll)),i=binSearch(l,v('q'),s=>s.roll);
  $('qr').innerHTML=i<0?'<span class="bad">No student with that roll number.</span>':`<span class="ok">Found: ${esc(l[i].name)} (Sem ${l[i].sem})</span> <span class="mu">(binary search)</span>`;
}

/* ---- Forms and lists ---- */
const hodForm=()=>db.depts.length?`<div class="card"><h3>Add HOD</h3><div class="row">
<label>Name<input id="n"></label><label>Username<input id="u"></label><label>Password<input id="p" type="password"></label>
<label>Department<select id="dp">${opts(db.depts.map(d=>[d.id,d.name]))}</select></label>
<button class="b" onclick="addUser('hod')">Add</button></div></div>`:noDept;
const studentForm=(dept,lock)=>`<div class="card"><h3>Add student</h3><div class="row">
<label>Name<input id="n"></label><label>Roll no.<input id="r"></label><label>Username<input id="u"></label><label>Password<input id="p" type="password"></label>
${lock?'':`<label>Semester<select id="sm">${opts(SEMS.map(s=>[s,semL(s)]),5)}</select></label>`}
<button class="b" onclick="addUser('student',{dept:'${dept}'${lock?`,sem:${lock}`:''}})">Add</button></div></div>`;
const deptPick=()=>{
  if(!db.depts.some(d=>d.id==tdept))tdept=(db.depts[0]||{}).id;
  return`<div class="card"><label style="max-width:300px">Department<select onchange="tdept=this.value;render()">${opts(db.depts.map(d=>[d.id,d.name]),tdept)}</select></label></div>`;
};
const semPick=(val,fn,all)=>`<div class="card"><label style="max-width:300px">${all?'Show':'Semester'}<select onchange="${fn}=+this.value;render()">${opts((all?[[0,'All semesters']]:[]).concat(SEMS.map(s=>[s,semL(s)])),val)}</select></label></div>`;
function staffView(dept){
  return SEMS.map(s=>{
    const l=subs(dept,s),ts=byRole('teacher',t=>t.dept==dept&&t.sem==s),free=l.filter(x=>!ts.some(t=>t.subject==x));
    const rows=l.map((x,i)=>{const t=ts.find(y=>y.subject==x);
      return[esc(x),t?esc(t.name):'<span class="bad">No teacher yet</span>',t?esc(t.user):'',t?delBtn('delUser',t.id,'Remove teacher'):'',`<button class="g d" onclick="ask(this,'delSubjectAt','${dept}|${s}|${i}')">Delete subject</button>`]});
    return`<div class="card"><h3>${semL(s)}</h3><p class="mu">${l.length} subjects, ${ts.length} teachers${free.length?', '+free.length+' without a teacher':''}</p>
${table(['Subject','Teacher','Username','',''],rows,'No subjects yet. Add the first one below.')}
<div class="row" style="margin-top:.75rem"><label>New subject<input id="sn${s}"></label><button class="b" onclick="addSubject('${dept}',${s})">Add subject</button></div>
${l.length?(free.length?`<h3 style="margin-top:1rem">Add teacher</h3><div class="row"><label>Name<input id="tn${s}"></label><label>Username<input id="tu${s}"></label><label>Password<input id="tp${s}" type="password"></label><label>Subject<select id="ts${s}">${opts(free.map(x=>[x,x]))}</select></label><button class="b" onclick="addTeacherAt('${dept}',${s})">Add teacher</button></div>`:'<p class="mu" style="margin-top:.75rem">Every subject has a teacher.</p>'):''}</div>`;
  }).join('');
}
function delSubjectAt(p){const a=p.split('|');delSubject(a[0],+a[1],+a[2])}
function studentsView(dept,lock,sj){
  const ss=mergeSort(byRole('student',s=>s.dept==dept&&(lock?s.sem==lock:(!fsem||s.sem==fsem))),bySem);
  return(lock?'':`<div class="stats">${SEMS.map(s=>stat(byRole('student',x=>x.dept==dept&&x.sem==s).length,semL(s))).join('')}</div>`)+
  studentForm(dept,lock)+(lock?'':semPick(fsem,'fsem',1))+
  `<div class="card"><h3>Find by roll number</h3><div class="row"><label>Roll no.<input id="q"></label><button class="b" onclick="findRoll()">Search</button></div><p id="qr"></p></div>
<div class="card"><h3>Students</h3>${table(['Roll','Name','Sem','Attendance'+(sj?' in '+esc(sj):'')+' (30 days)',''],ss.map(s=>{const p=monthPct(s.id,sj);return[esc(s.roll),esc(s.name),s.sem,`<span class="${pcCls(p)}">${p==null?'-':p+'%'}</span>`,delBtn('delUser',s.id)]}),'No students yet.')}</div>`;
}
function hodReports(){
  const from=iso(ago(29)),ts=mergeSort(byRole('teacher',t=>t.dept==me.dept&&(!fsem||t.sem==fsem)),(a,b)=>a.sem-b.sem||a.subject.localeCompare(b.subject));
  const rows=ts.map(t=>{const ses=db.attendance.filter(a=>a.teacher==t.id&&a.date>=from);let p=0,n=0;ses.forEach(a=>Object.values(a.rec).forEach(x=>{n++;if(x)p++}));
    const q=n?Math.round(p*100/n):null;
    return[esc(t.name),esc(t.subject),'Sem '+t.sem,ses.length,`<span class="${pcCls(q)}">${q==null?'-':q+'%'}</span>`,db.materials.filter(m=>m.teacher==t.id).length]});
  const ss=mergeSort(byRole('student',s=>s.dept==me.dept&&(!fsem||s.sem==fsem)&&monthPct(s.id)!=null),(a,b)=>monthPct(a.id)-monthPct(b.id));
  return semPick(fsem,'fsem',1)+`<div class="card"><h3>Teacher reports (last 30 days)</h3>${table(['Teacher','Subject','Semester','Lectures taken','Class attendance','Materials'],rows,'No teachers yet.')}</div>
<div class="card"><h3>Students by attendance, lowest first</h3><p class="mu">Sorted with merge sort, O(n log n). Red bars are below 75%.</p>${bars(ss.map(s=>({l:s.name+' (Sem '+s.sem+')',v:monthPct(s.id),t:monthPct(s.id)+'%'})),100,75)||'<p class="mu">No data yet.</p>'}</div>`;
}

/* ---- Panels ---- */
const VIEWS={
principal:[
()=>{
  const rows=db.depts.map(d=>[esc(d.name),esc((byRole('hod',h=>h.dept==d.id)[0]||{}).name||'Not assigned'),byRole('teacher',t=>t.dept==d.id).length].concat(SEMS.map(s=>byRole('student',x=>x.dept==d.id&&x.sem==s).length)));
  const at=db.depts.map(d=>{const p=classPct(t=>t.dept==d.id);return{l:d.name,v:p||0,t:p==null?'-':p+'%'}});
  return`<div class="stats">${stat(db.depts.length,'Departments')}${stat(byRole('hod').length,'HODs')}${stat(byRole('teacher').length,'Teachers')}${stat(byRole('student').length,'Students')}</div>
<div class="card"><h3>Departments at a glance</h3>${table(['Department','HOD','Teachers'].concat(SEMS.map(s=>'Sem '+s+' students')),rows,'No departments yet.')}</div>
<div class="card"><h3>Subjects and teachers by semester</h3>${table(['Department'].concat(SEMS.map(s=>'Sem '+s)),db.depts.map(d=>[esc(d.name)].concat(SEMS.map(s=>subs(d.id,s).length+' subjects, '+byRole('teacher',t=>t.dept==d.id&&t.sem==s).length+' teachers'))),'No departments yet.')}</div>
<div class="card"><h3>Attendance by department, last 30 days</h3><p class="mu">Red bars are below 75%.</p>${bars(at,100,75)||'<p class="mu">No data yet.</p>'}</div>`},
()=>`<div class="card"><h3>Add department</h3><div class="row"><label>Name<input id="dname"></label><button class="b" onclick="addDept()">Add</button></div></div>
<div class="card">${table(['Department','HOD','Teachers','Students',''],db.depts.map(d=>[esc(d.name),esc((byRole('hod',h=>h.dept==d.id)[0]||{}).name||'Not assigned'),byRole('teacher',t=>t.dept==d.id).length,byRole('student',s=>s.dept==d.id).length,delBtn('delDept',d.id)]),'No departments yet.')}</div>`,
()=>hodForm()+`<div class="card"><h3>HOD of each department</h3>${table(['Department','HOD','Username',''],db.depts.map(d=>{const h=byRole('hod',x=>x.dept==d.id)[0];return[esc(d.name),h?esc(h.name):'<span class="mu">Not assigned</span>',h?esc(h.user):'',h?delBtn('delUser',h.id):'']}),'No departments yet.')}</div>`,
()=>db.depts.length?deptPick()+staffView(tdept):noDept
],
hod:[
()=>`<h2>${esc(dn(me.dept))} teachers and subjects</h2><p class="mu">Subjects and their teachers, semester by semester. The timetable picks from these subjects.</p>`+staffView(me.dept),
()=>`<h2>${esc(dn(me.dept))} students</h2>`+studentsView(me.dept),
()=>`<h2>Weekly timetable</h2><p class="mu">Choose a subject for each slot. Changes save automatically and students see them at once.</p>`+semPick(tsem,'tsem')+ttView(me.dept,tsem,true),
()=>`<h2>${esc(dn(me.dept))} reports</h2>`+hodReports(),
()=>stuReport(me.dept,0)
],
teacher:[
()=>`<h2>${semL(me.sem)} students</h2>`+studentsView(me.dept,me.sem,me.subject),
()=>`<div class="card"><h3>Add ${esc(me.subject)} material</h3><div class="row"><label>Title<input id="mt"></label><label>Link or note<input id="ml"></label><button class="b" onclick="addMaterial()">Add</button></div></div>
<div class="card">${table(['Title','Link / note',''],db.materials.filter(m=>m.teacher==me.id).map(m=>[esc(m.title),lk(m.link),delBtn('delMat',m.id)]),'No materials yet.')}</div>`,
()=>{const ss=mergeSort(byRole('student',s=>s.dept==me.dept&&s.sem==me.sem),(a,b)=>cmpNum(a.roll,b.roll));
return`<div class="card"><h3>Mark ${esc(me.subject)} attendance</h3><label style="max-width:220px">Date<input id="ad" type="date" value="${iso(new Date())}"></label>
${ss.length?ss.map(s=>`<label class="chk"><input type="checkbox" id="c${s.id}" checked> ${esc(s.roll)} · ${esc(s.name)}</label>`).join('')+'<p><button class="b" onclick="saveAtt()">Save attendance</button></p>':'<p class="mu">Add students first.</p>'}</div>
<div class="card"><h3>Past sessions</h3>${table(['Date','Present','Absent',''],db.attendance.filter(a=>a.teacher==me.id).sort((a,b)=>b.date.localeCompare(a.date)).slice(0,15).map(a=>{const k=Object.keys(a.rec);return[a.date,k.filter(x=>a.rec[x]).length,k.filter(x=>!a.rec[x]).length,delBtn('delAtt',a.id)]}),'No sessions yet.')}</div>`},
()=>stuReport(me.dept,me.sem,me.subject)
],
student:[
()=>`<h2>${esc(me.name)} <span class="mu">Roll ${esc(me.roll)}, ${semL(me.sem)}, ${esc(dn(me.dept))}</span></h2>`+attReport(me.id),
()=>`<h2>Weekly timetable, ${semL(me.sem)}</h2>`+ttView(me.dept,me.sem,false),
()=>`<div class="card"><h3>Subject materials</h3>${table(['Subject','Title','Link / note','Teacher'],db.materials.filter(m=>m.dept==me.dept&&m.sem==me.sem).sort((a,b)=>subs(me.dept,me.sem).indexOf(a.subject)-subs(me.dept,me.sem).indexOf(b.subject)).map(m=>[esc(m.subject),esc(m.title),lk(m.link),esc(U(m.teacher).name)]),'No materials yet.')}</div>`,
()=>resultsCard(me.id,false)
]};
const TABS={principal:['Overview','Departments','HODs','Teachers and subjects'],hod:['Teachers and subjects','Students','Timetable','Reports','Student report'],teacher:['Students','Materials','Attendance','Student report'],student:['Attendance','Timetable','Materials','Results']};

function render(){
  const app=$('app');
  if(!me){
    app.innerHTML=`<div class="login card"><h1>College Management System</h1><p class="mu">Sign in to your panel.</p>
<label>Username<input id="lu" autocomplete="username"></label><br><label>Password<input id="lp" type="password" autocomplete="current-password" onkeydown="if(event.key=='Enter')login()"></label>
<p class="bad" id="err"></p><button class="b" onclick="login()">Sign in</button>
<p class="hint"><b>Principal:</b> principal / admin123<br><b>HODs</b> (password hod123): hod (CSE), hod.it, hod.ce, hod.me<br><b>CSE Sem 5 teachers</b> (password t123): aad, ds, pm, cs, ss, wad. Every other teacher's username is in the Teachers tab, with the same password.<br><b>CSE Sem 5 students</b> (password s123): dev, tushar, apurv, priyansh, keyur<br><b>Juniors and seniors</b> (password s123): cse3s1 (Sem 3), cse7s1 (Sem 7)</p></div>`;return;
  }
  const names={principal:'Principal',hod:'Head of Department',teacher:'Subject Teacher',student:'Student'};
  const who=me.role=='hod'?' · '+dn(me.dept):me.role=='teacher'?' · '+me.subject+' · '+dn(me.dept)+' Sem '+me.sem:me.role=='student'?' · '+dn(me.dept)+' Sem '+me.sem:'';
  app.innerHTML=`<header><div><b>College Management System</b><br><span>${names[me.role]}${esc(who)}</span></div><div><span>${esc(me.name)}</span> <button class="g" onclick="logout()">Sign out</button></div></header>
<nav>${TABS[me.role].map((t,i)=>`<button class="${i==tab?'on':''}" onclick="tab=${i};render()">${t}</button>`).join('')}</nav>
<main>${VIEWS[me.role][tab]()}</main>`;
}
render();
